O programa deve ser utilizado de forma bem especifica, deve-se fornecer um arquivo .txt na pasta 
individuos cujo o nome seja um úmero e que siga a ordem a partir dos ja existentes. Este arquivo 
deve ter uma formatação semelhante com os outros para que funcione de forma apropriada.
Explicação do programa: o programa ira ler o arquivo fornecido e coletará as informações a partir de 
tratamento de string, essas informações serão enviadas para o modulo conta, que executara a criação
das contas para o cliente.